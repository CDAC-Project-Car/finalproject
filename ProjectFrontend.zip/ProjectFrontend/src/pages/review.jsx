import React, { useState } from 'react';
import { Container, Row, Col, Card, Button, Form } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function Review ()  {
  // State to hold the list of reviews
  const [reviews, setReviews] = useState([
    { id: 1, text: 'Great product!', rating: 5 },
    { id: 2, text: 'Good quality, but could be improved.', rating: 4 }
  ]);

  // State for form input values
  const [reviewText, setReviewText] = useState('');
  const [rating, setRating] = useState(1);

  const navigate = useNavigate();
  // Handle form submission
//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (reviewText) {
//       setReviews([...reviews, { id: reviews.length + 1, text: reviewText, rating }]);
//       setReviewText('');
//       setRating(1);
//       toast.success("Reviw submitted successfully");
//         navigate('/home');
//     }
//   };

const handleSubmit = () => {
    
      toast.success("Reviw submitted successfully");
        navigate('/home');
  };

  return (
    <div className='center' style={{align:'center', backgroundColor:"lightblue"}}>
      
        <h5>Submit Your Review</h5>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="exampleRadios" id="1 star" value="1 star"/>
            <label class="form-check-label" for="exampleRadios1">1 star</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="exampleRadios" id="2 star" value="2 star"/>
            <label class="form-check-label" for="exampleRadios2"> 2 star </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="exampleRadios" id="3 star" value="3 star" />
            <label class="form-check-label" for="exampleRadios1"> 3 star </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="exampleRadios" id="4 star" value="4 star"/>
            <label class="form-check-label" for="exampleRadios2"> 4 star </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="exampleRadios" id="5 star" value="5 star"/>
            <label class="form-check-label" for="exampleRadios2"> 5 star </label>
        </div>
        <div data-coreui-allow-clear="true" data-coreui-toggle="rating" data-coreui-value="3"></div>
        <textarea id="reviewText" name="reviewText" rows="4" cols="50" placeholder='Enter text here'></textarea>
        <button type="submit" class="btn btn-primary mt-3" onClick={handleSubmit}>Submit Review</button>
    </div>
  );
};

export default Review;
