import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

function Edit()
{
    return <div>
        <Navbar/>
            <div className="container">
                <h2 className="title mb-4 mt-4"><center>Edit car details</center></h2>
            </div>
        <Footer/>
    </div>
}

export default Edit;