import Navbar from "../components/Navbar"
import Footer from "../components/Footer"


export default function CarDetails()
{
    return(
        <div>
        <Navbar/>
        <div className="container">
        <h2 className="title"> <center>Car Details page</center> </h2>
        </div>
        <Footer/>
    </div>
    )
}