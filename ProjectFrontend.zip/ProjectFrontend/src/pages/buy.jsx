import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import React, { useState, useEffect } from "react";
import { getcarDetails } from "../services/car";
import { addToCart } from "../services/cart";
import FeatureCheckbox from "../components/FeatureCheckBox";
import CheckboxList from "../components/CardsGroups/CheckboxList";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function Buy() {
  const [carData, setCarData] = useState("");
  const [carModelDetails, setCarModelDetails] = useState("");
  const [modelSpecificationDetails, setModelSpecificationDetails] =
    useState("");
  const [userDetails, setUserDetails] = useState("");
  const [images, setImages] = useState("");

  const [carModelCompany, setCarModelCompany] = useState(null);
  const [modelName, setModelName] = useState(null);
  const [carSellingPrice, setCarSellingPrice] = useState(null);

  const load = async () => {
    const result = await getcarDetails(128);
    setCarData(result);
    setCarModelDetails(result.carModelDetails);
    setModelSpecificationDetails(result.modelSpecificationDetails);
    setUserDetails(result.userDetails);
    setImages(result.images);
  };

  useEffect(() => {
    load();
  }, []);

  const navigate = useNavigate();

  const onAddToWishlist = async () => {
    const cartRequestDTO = {
      carModelCompany: carModelDetails.carModelCompany,
      modelName: carModelDetails.modelName,
      carSellingPrice: carModelDetails.carSellingPrice,
    };

    const formData = new FormData();

    formData.append(
      "dto",
      new Blob([JSON.stringify(cartRequestDTO)], { type: "application/json" })
    );

    const result = await addToCart(formData);
    //toast.success(result.message);
    navigate("/wishlist");
  };

  const paymentPage = () => {
    navigate("/payment"); // Navigate to the "/about" route
  };

  //   const {
  //     carNumber,
  //     isInsurance,
  //     rtoLocation,
  //     carMfgYear,
  //     kmsDriven,
  //     carMilage,
  //     carColor,
  //     carStatus,
  //     carSellingPrice,
  //   } = carData;

  return (
    <div className="Buy">
      <Navbar />
      <table width="100%">
        <tr>
          <td width="50%">
            <div className="container mt-4">
              <div className="col-md-8">
                <img
                  src="https://www.freepnglogos.com/uploads/honda-car-png/honda-car-upcoming-new-honda-cars-india-new-honda-3.png"
                  alt=""
                />
              </div>

              {/* <div className="col-md-8">
                  <img src={images.imagePath} class="img-fluid" alt="Responsive image" />                   
                </div> */}

              {/* General Car Details Table */}
              <div className="card mb-4">
                <div className="card-header">
                  <h5 className="mb-0">General Information</h5>
                </div>
                <div className="card-body">
                  <table className="table table-bordered table-striped">
                    <tbody>
                      <tr>
                        <th scope="row">Car Number</th>
                        <td>{carData.carNumber}</td>
                      </tr>
                      <tr>
                        <th scope="row">Insurance</th>
                        <td>{carData.isInsurance ? "Yes" : "No"}</td>
                      </tr>
                      <tr>
                        <th scope="row">RTO Location</th>
                        <td>{carData.rtoLocation}</td>
                      </tr>
                      <tr>
                        <th scope="row">Manufacturing Year</th>
                        <td>{carData.carMfgYear}</td>
                      </tr>
                      <tr>
                        <th scope="row">Kms Driven</th>
                        <td>{carData.kmsDriven}</td>
                      </tr>
                      <tr>
                        <th scope="row">Milage</th>
                        <td>{carData.carMilage}</td>
                      </tr>
                      <tr>
                        <th scope="row">Color</th>
                        <td>{carData.carColor}</td>
                      </tr>
                      <tr>
                        <th scope="row">Status</th>
                        <td>
                          {carData.carStatus ? "Available" : "Not Available"}
                        </td>
                      </tr>
                      <tr>
                        <th scope="row">Selling Price</th>
                        <td>{carData.carSellingPrice}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div
                style={{ fontWeight: "bold", fontSize: 20 }}
                className="mb-1"
              >
                Currently available features ::{" "}
              </div>
              {/* Feature checkBoxes */}

              <div className="row">
                <div className="col">
                  <CheckboxList
                    id="check1"
                    label="Power Steering ?"
                    checked={modelSpecificationDetails.isPowerSteering}
                    // onChange={(e) => setModelSpecificationDetails.isPowerSteering(e.target.checked)}
                  />
                </div>
                <div className="col">
                  <CheckboxList
                    id="check2"
                    label="Power Windows ?"
                    checked={modelSpecificationDetails.isPowerWindows}
                    // onChange={(e) => setModelSpecificationDetails.isPowerWindows(e.target.checked)}
                  />
                </div>
              </div>

              <div className="row">
                <div className="col">
                  <CheckboxList
                    id="check3"
                    label="Air Conditioner ?"
                    checked={modelSpecificationDetails.isAirConditioner}
                    // onChange={(e) => setModelSpecificationDetails.isAirConditioner(e.target.checked)}
                  />
                </div>
                <div className="col">
                  <CheckboxList
                    id="check4"
                    label="Adjustable Head Light ?"
                    checked={modelSpecificationDetails.isAdjustableHeadLight}
                    // onChange={(e) => setModelSpecificationDetails.isAdjustableHeadLight(e.target.checked)}
                  />
                </div>
              </div>

              <div className="row">
                <div className="col">
                  <CheckboxList
                    id="check5"
                    label="Fog Lights ?"
                    checked={modelSpecificationDetails.isFogLights}
                    // onChange={(e) => setModelSpecificationDetails.isFogLights(e.target.checked)}
                  />
                </div>
                <div className="col">
                  <CheckboxList
                    id="check6"
                    label="ABS available ?"
                    checked={modelSpecificationDetails.isABS}
                    // onChange={(e) => setModelSpecificationDetails.isABS(e.target.checked)}
                  />
                </div>
              </div>

              <div className="row">
                <div className="col">
                  <CheckboxList
                    id="check7"
                    label="Brake Assist ?"
                    checked={modelSpecificationDetails.isBrakeAssist}
                    // onChange={(e) => setModelSpecificationDetails.isBrakeAssist(e.target.checked)}
                  />
                </div>
                <div className="col">
                  <CheckboxList
                    id="check8"
                    label="Music System ?"
                    checked={modelSpecificationDetails.isMusicSystem}
                    // onChange={(e) => setModelSpecificationDetails.isMusicSystem(e.target.checked)}
                  />
                </div>
              </div>

              <div className="row">
                <div className="col">
                  <CheckboxList
                    id="check9"
                    label="Speakers ?"
                    checked={modelSpecificationDetails.isSpeakers}
                    // onChange={(e) => setModelSpecificationDetails.isSpeakers(e.target.checked)}
                  />
                </div>
                <div className="col">
                  <FeatureCheckbox
                    id="check10"
                    label="Adjustable Seats ?"
                    checked={modelSpecificationDetails.isAdjustableSeats}
                    onChange={(e) =>
                      setModelSpecificationDetails.isAdjustableSeats(
                        e.target.checked
                      )
                    }
                  />
                </div>
              </div>

              <div className="row">
                <div className="col">
                  <CheckboxList
                    id="check11"
                    label="Cruise Control ?"
                    checked={modelSpecificationDetails.isCruiseControl}
                    // onChange={(e) => setModelSpecificationDetailss.isCruiseControl(e.target.checked)}
                  />
                </div>
                <div className="col">
                  <CheckboxList
                    id="check12"
                    label="Navigation System ?"
                    checked={modelSpecificationDetails.isNavigationSystem}
                    // onChange={(e) => setModelSpecificationDetails.isNavigationSystem(e.target.checked)}
                  />
                </div>
              </div>

              <div className="row">
                <div className="col">
                  <CheckboxList
                    id="check13"
                    label="Power Adjustable Mirrors ?"
                    checked={modelSpecificationDetails.isPowerAdjustableMirrors}
                    // onChange={(e) => setModelSpecificationDetails.isPowerAdjustableMirrors(e.target.checked)}
                  />
                </div>
                <div className="col">
                  <CheckboxList
                    id="check14"
                    label="Sunroof ?"
                    checked={modelSpecificationDetails.isSunroof}
                    // onChange={(e) => setModelSpecificationDetails.isSunroof(e.target.checked)}
                  />
                </div>
              </div>

              <div className="row">
                <div className="col">
                  <CheckboxList
                    id="check15"
                    label="Airbags ?"
                    checked={modelSpecificationDetails.isAirbags}
                    // onChange={(e) => setModelSpecificationDetails.isAirbags(e.target.checked)}
                  />
                </div>
                <div className="col">
                  <CheckboxList
                    id="check16"
                    label="Seatbelts ?"
                    checked={modelSpecificationDetails.isSeatBelt}
                    // onChange={(e) => setModelSpecificationDetails.isSeatBelt(e.target.checked)}
                  />
                </div>
              </div>

              <div className="row">
                <div className="col">
                  <CheckboxList
                    id="check18"
                    label="Central Locking ?"
                    checked={modelSpecificationDetails.isCentralLocking}
                    // onChange={(e) => setModelSpecificationDetails.isCentralLocking(e.target.checked)}
                  />
                </div>
              </div>
            </div>
          </td>

          <td width="50%">
            <h1 className="mb-4">Car Details</h1>

            {/* Car Model Details Table */}
            <div className="card mb-4">
              <div className="card-header">
                <h5 className="mb-0">Car Model Details</h5>
              </div>
              <div className="card-body">
                <table className="table table-bordered table-striped">
                  <tbody>
                    <tr>
                      <th scope="row">Company</th>
                      <td>{carModelDetails.carModelCompany}</td>
                    </tr>
                    <tr>
                      <th scope="row">Model Name</th>
                      <td>{carModelDetails.modelName}</td>
                    </tr>
                    <tr>
                      <th scope="row">Series Name</th>
                      <td>{carModelDetails.carSeriesName}</td>
                    </tr>
                    <tr>
                      <th scope="row">Type</th>
                      <td>{carModelDetails.carModelType}</td>
                    </tr>
                    <tr>
                      <th scope="row">Transmission</th>
                      <td>{carModelDetails.transmission}</td>
                    </tr>
                    <tr>
                      <th scope="row">Gearbox</th>
                      <td>{carModelDetails.gearbox}</td>
                    </tr>
                    <tr>
                      <th scope="row">Front Brake Type</th>
                      <td>{carModelDetails.frontBrakeType}</td>
                    </tr>
                    <tr>
                      <th scope="row">Rear Brake Type</th>
                      <td>{carModelDetails.rearBrakeType}</td>
                    </tr>
                    <tr>
                      <th scope="row">Drivetrain</th>
                      <td>{carModelDetails.drivetrain}</td>
                    </tr>
                    <tr>
                      <th scope="row">Emission Norm</th>
                      <td>{carModelDetails.emissionNorm}</td>
                    </tr>
                    <tr>
                      <th scope="row">Fuel Tank Capacity</th>
                      <td>{carModelDetails.fuelTankCapacity} L</td>
                    </tr>
                    <tr>
                      <th scope="row">Ground Clearance</th>
                      <td>{carModelDetails.groundClearance} mm</td>
                    </tr>
                    <tr>
                      <th scope="row">Tyre Type</th>
                      <td>{carModelDetails.tyreType}</td>
                    </tr>
                    <tr>
                      <th scope="row">Cargo Volume</th>
                      <td>{carModelDetails.cargoVolume} L</td>
                    </tr>
                    <tr>
                      <th scope="row">Seating Capacity</th>
                      <td>{carModelDetails.seatingCapacity}</td>
                    </tr>
                    <tr>
                      <th scope="row">Engine Displacement</th>
                      <td>{carModelDetails.engineDisplacement} cc</td>
                    </tr>
                    <tr>
                      <th scope="row">Max Power</th>
                      <td>{carModelDetails.maxPower} PS</td>
                    </tr>
                    <tr>
                      <th scope="row">Max Torque</th>
                      <td>{carModelDetails.maxTorque} Nm</td>
                    </tr>
                    <tr>
                      <th scope="row">No of Cylinders</th>
                      <td>{carModelDetails.noOfCylinders}</td>
                    </tr>
                    <tr>
                      <th scope="row">Fuel Type</th>
                      <td>{carModelDetails.fuelType}</td>
                    </tr>
                    <tr>
                      <th scope="row">Length</th>
                      <td>{carModelDetails.length} mm</td>
                    </tr>
                    <tr>
                      <th scope="row">Width</th>
                      <td>{carModelDetails.width} mm</td>
                    </tr>
                    <tr>
                      <th scope="row">Height</th>
                      <td>{carModelDetails.height} mm</td>
                    </tr>
                    <tr>
                      <th scope="row">Wheel Base</th>
                      <td>{carModelDetails.wheelBase} mm</td>
                    </tr>
                    <tr>
                      <th scope="row">Gross Weight</th>
                      <td>{carModelDetails.grossWeight} kg</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <button
              className="btn btn-primary"
              style={{ marginRight: "20px" }}
              onClick={paymentPage}
            >
              Book Now
            </button>

            <button className="btn btn-primary" onClick={onAddToWishlist}>
              Add to Wishlist
            </button>
          </td>
        </tr>
      </table>

      <Footer />
    </div>
  );
}

export default Buy;
