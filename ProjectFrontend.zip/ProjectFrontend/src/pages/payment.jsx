import React, { useState } from 'react';
import { Container, Row, Col, Card, Button, Form } from 'react-bootstrap';
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import CardsGroups from "../components/CardsGroups/CardsGroups";
// src/index.js or src/App.js
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";



function Payment () {
//   const [paymentMethod, setPaymentMethod] = useState('');

//   const handlePaymentMethodChange = (event) => {
//     setPaymentMethod(event.target.value);
//   };
const navigate = useNavigate();

  const handleSubmit = () => {
    toast.success("Payment successfull");
    navigate('/review');
  };

  return (
    <div >
        <Navbar />
        <div class="container" >
        <div class="row m-0" >
            <div class="col-lg-5 p-0 ps-lg-4" >
                <div class="row m-0"  style={{backgroundColor:"gray"}}>
                    <div class="col-12 px-4">
                        <div class="d-flex align-items-end mt-4 mb-2">
                            <p class="h4 m-0"><span class="pe-1">Maruti Suzuki</span><span class="pe-1">Swift </span><span
                                    class="pe-1">DLS</span></p>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <p class="textmuted">Qty</p>
                            <p class="fs-14 fw-bold">1</p>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <p class="textmuted">Subtotal</p>
                            <p class="fs-14 fw-bold">500</p>
                        </div>
                        {/* <div class="d-flex justify-content-between mb-2">
                            <p class="textmuted">Shipping</p>
                            <p class="fs-14 fw-bold">Free</p>
                        </div> */}
                        {/* <div class="d-flex justify-content-between mb-2">
                            <p class="textmuted">Promo code</p>
                            <p class="fs-14 fw-bold">-<span class="fas fa-dollar-sign px-1"></span>100</p>
                        </div> */}
                        <div class="d-flex justify-content-between mb-3">
                            <p class="textmuted fw-bold">Total</p>
                            <div class="d-flex align-text-top ">
                                <span class="h4">500</span>
                            </div>
                        </div>

                        <div class="col-12 px-4 my-4">
                                <p class="fw-bold">Payment detail</p>
                            </div>

                            <div class="d-flex  mb-4">
                                    <span class="">
                                        <p class="text-muted">Card number</p>
                                        <input class="form-control" type="text" value="4485 6888 2359 1498"
                                            placeholder="1234 5678 9012 3456"  disabled/>
                                    </span>
                                    <div class=" w-100 d-flex flex-column align-items-end">
                                        <p class="text-muted">Expires</p>
                                        <input class="form-control2" type="text" value="01/2026" placeholder="MM/YYYY" disabled/>
                                    </div>
                                </div>
                                <div class="d-flex mb-5">
                                    <span class="me-5">
                                        <p class="text-muted">Cardholder name</p>
                                        <input class="form-control" type="text" value="Cardholder nam"
                                            placeholder="Name" disabled/>
                                    </span>
                                    <div class="w-100 d-flex flex-column align-items-end">
                                        <p class="text-muted">CVC</p>
                                        <input class="form-control3" type="text" value="630" placeholder="XXX" disabled />
                                    </div>
                                </div>
                                <div class="col-12  mb-4 p-0">
                                <button className="btn btn-primary" onClick={handleSubmit} >Pay Now</button>
                                
                            </div>
                    </div>



                    
                </div>
            </div>
        </div>
        </div>
        
        <Footer />
    </div>
    // <div className="main-page">
    // <Navbar />
    // <div class="container mt-5">
    // <div class="row justify-content-center">
    //     <div class="col-md-8">
    //         <div class="card payment-card">
    //             <div class="card-header">
    //                 <h5 class="mb-0">Payment Options</h5>
    //             </div>
    //             <div class="card-body">
    //                 <form>
    //                     <div class="form-group">
    //                         <label>Select Payment Method</label>
    //                         <div class="form-check">
    //                             <input class="form-check-input" type="radio" name="paymentMethod" id="cash" value="cash" />
    //                             <label class="form-check-label" for="cash">
    //                                 Cash
    //                             </label>
    //                         </div>
    //                         <div class="form-check">
    //                             <input class="form-check-input" type="radio" name="paymentMethod" id="card" value="card" />
    //                             <label class="form-check-label" for="card">
    //                                 Card
    //                             </label>
    //                         </div>
    //                         <div class="form-check">
    //                             <input class="form-check-input" type="radio" name="paymentMethod" id="phonepe" value="phonepe" />
    //                             <label class="form-check-label" for="phonepe">
    //                                 PhonePe
    //                             </label>
    //                         </div>
    //                         <div class="form-check">
    //                             <input class="form-check-input" type="radio" name="paymentMethod" id="googlepay" value="googlepay" />
    //                             <label class="form-check-label" for="googlepay">
    //                                 Google Pay
    //                             </label>
    //                         </div>
    //                     </div>
    //                     <button type="submit" class="btn btn-primary mt-3" onClick={handleSubmit}>Proceed to Pay</button>
    //                 </form>
    //             </div>
    //         </div>
    //     </div>
    // </div>
    // </div>
    // {/* <CardsGroups title="Why use CarBazaar ?" data={CARDDATA} /> */}
    // {/* <FAQ /> */}

    // <Footer />
    // </div>
  );
};

export default Payment;
