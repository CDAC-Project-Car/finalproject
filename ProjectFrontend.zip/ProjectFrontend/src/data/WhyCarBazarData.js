export const CARDDATA = {'Cards':[
    {
      'title':'Sell from anywhere',
      'description':'From inspection to payment, everything right from your doorstep!'
    },
    {
      'title':'Instant payment',
      'description':'The amount is transferred directly to your bank account within minutes'
    },
    {
      'title':'Great price',
      'description':'Largest dealer network + Smart AI Pricing Engine = great deal for your car'
    },
    {
      'title':'Simple Functionality',
      'description':'Anyone can use it, no more hassle of understanding complex site'
    },
  
  ]
}
  