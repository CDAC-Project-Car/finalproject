export const DATA = {'Hatchback':[
    {
      'title':'Hyundai i20',
      'price':'Rs 6.91 - 11.40 Lakh',
      'image':'https://stimg.cardekho.com/images/carexteriorimages/630x420/Hyundai/i20/6986/1604567349336/front-left-side-47.jpg'
    },
    {
      'title':'Maruti Swift',
      'price':'Rs 5.85 - 8.67 Lakh',
      'image':'https://stimg.cardekho.com/images/carexteriorimages/630x420/Maruti/Swift/8378/1614747593719/front-left-side-47.jpg'
    },
    {
      'title':'Tata Altroz',
      'price':'Rs 5.84 - 9.59 Lakh',
      'image':'https://stimg.cardekho.com/images/carexteriorimages/630x420/Tata/Altroz/7247/1578642800962/front-left-side-47.jpg'
    },
    {
      'title':'Maruti Baleno',
      'price':'Rs 5.99 - 9.45 Lakh',
      'image':'https://stimg.cardekho.com/images/carexteriorimages/630x420/Maruti/Baleno/6778/1615985070703/front-left-side-47.jpg'
    },
  
  ], 'Sedan':{}, 'SUV':{}, 'MUV':{}, 'Luxury':{}}
  
  export const DATA1 = {'1-5 LAKH':[
    {
      'title':'Maruti Swift',
      'price':'Starting @ Rs1.2 Lakh',
      'image':'https://stimg.cardekho.com/images/carexteriorimages/630x420/Maruti/Swift/8378/1614747593719/front-left-side-47.jpg',
      'available':'33 Available Cars'
    },
    {
      'title':'Hyundai I10',
      'price':'Starting @ Rs1.15 Lakh',
      'image':'https://stimg.cardekho.com/images/carexteriorimages/630x420/Hyundai/Hyundai-i10/2691/front-left-side-47.jpg',
      'available': '114 Available Cars'
    },
    {
      'title':'Maruti Swift Dzire',
      'price':'Starting @ Rs1.5 Lakh',
      'image':'https://stimg.cardekho.com/images/carexteriorimages/630x420/Maruti/Dzire-2020/7664/1584705998420/front-left-side-47.jpg',
      'available': '100 Available Cars'
    },
    {
      'title':'Maruti Wagon R',
      'price':'Starting @ Rs1.15 Lakh',
      'image':'https://stimg.cardekho.com/images/carexteriorimages/630x420/Maruti/Maruti-Wagon-R/6741/1564746908438/front-left-side-47.jpg',
      'available': '99 Available Cars'
    },
  
  ], '5-10 LAKH':{}, '10-15 LAKH':{}}
  
  export const DATA2 = {
      "normal":[
    {
      'title':'Tata Safari XZA Plus Gold AT',
      'price':'Rs 23.17 Lakh',
      'image':'https://stimg.cardekho.com/images/carexteriorimages/630x420/Tata/New-Safari/8376/Tata-New-Safari-XZA-Plus-Adventure-Edition-AT/1614147643555/front-left-side-47.jpg',
    },
    {
      'title':'Kia Carnival',
      'price':'Rs 24.95 - 33.99 Lakh',
      'image':'https://stimg.cardekho.com/images/carexteriorimages/630x420/Kia/Carnival/7015/1589535511670/front-left-side-47.jpg',
    },
    {
      'title':'BMW X5',
      'price':'Rs 76.50 - 88.00 Lakh',
      'image':'https://stimg.cardekho.com/images/carexteriorimages/630x420/BMW/BMW-X5/6455/1558002027816/front-left-side-47.jpg',
    },
    {
      'title':'Hyundai Alcazar Platinum 7-Seater',
      'price':'Rs 19.63 Lakh',
      'image':'https://stimg.cardekho.com/images/carexteriorimages/630x420/Hyundai/Alcazar/8459/1624013603874/front-left-side-47.jpg'
    },
  
  ]
}