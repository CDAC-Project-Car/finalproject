import axios from "axios";
import { toast } from "react-toastify";


export async function addToCart(formData) {

    try {
      const response = await axios.post("http://localhost:8080/cart/{formData}/add");
      return response.data;
    } catch (error) {
      toast.error(error)
    }
  }